const express = require("express");
const app = express();
app.get("/",function(request,res){
  res.sendFile(__dirname + "/markwebsite.html")
});
app.listen(3000,function(){
  console.log("Srever started on port 3000");
});
